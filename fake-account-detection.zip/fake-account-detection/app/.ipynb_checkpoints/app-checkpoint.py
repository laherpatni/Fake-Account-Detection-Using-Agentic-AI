# ==============================================
# app/app.py — Fake Account Detection Dashboard (FINAL STABLE + UI ENHANCED OVERVIEW/ABOUT)
# ==============================================

import sys, os
from pathlib import Path
import streamlit as st
import pandas as pd
import numpy as np
import torch
import torch.nn.functional as F
from torch_geometric.nn import SAGEConv
import pickle

# ===== Add src folder for imports =====
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SRC_DIR = os.path.join(ROOT_DIR, "src")
if SRC_DIR not in sys.path:
    sys.path.insert(0, SRC_DIR)

# === Import Local LLM helper ===
from llm_utils import generate_reasoning

# ================================
# Page Config + Theme
# ================================
st.set_page_config(page_title="Fake Account Detector", layout="wide", page_icon="🔎")

custom_css = """
<style>
body { background-color: #0f1116; color: #fafafa; font-family: 'Segoe UI', sans-serif; }
[data-testid="stSidebar"] { background-color: #1b1e23; }
[data-testid="stAppViewContainer"] { background: linear-gradient(135deg, #0f0f0f, #1a1a1a); }
h1, h2, h3, h4 { color: #fafafa; }
h1 { font-weight: 800; background: linear-gradient(90deg, #F44336, #E91E63); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
p { color: #ccc; font-size: 16px; line-height: 1.6; }
.stTabs [data-baseweb="tab-list"] { gap: 2em; }
.stTabs [data-baseweb="tab"] {
    background-color: #1b1e23; color: white; border-radius: 10px; padding: 10px 20px;
}
.stTabs [aria-selected="true"] { background-color: #3b3f46 !important; font-weight: bold; }
div[data-testid="stExpander"] { background-color: #1b1e23; border-radius: 10px; }
div.stButton > button {
    background-color: #F44336; color: white; border-radius: 12px;
    padding: 10px 24px; font-size: 16px;
}
hr { border: 1px solid #333; margin: 20px 0; }
</style>
"""
st.markdown(custom_css, unsafe_allow_html=True)

# ================================
# Paths
# ================================
MODELS_DIR = os.path.join(ROOT_DIR, "models")
RAG_INDEX_DIR = os.path.join(ROOT_DIR, "rag_index")
print("📁 Models directory:", MODELS_DIR)
print("📁 RAG directory:", RAG_INDEX_DIR)

# ================================
# Define Graph Models
# ================================
class GraphSAGENet(torch.nn.Module):
    def __init__(self, in_channels, hidden_channels=64, out_channels=2, dropout=0.5):
        super().__init__()
        self.conv1 = SAGEConv(in_channels, hidden_channels)
        self.conv2 = SAGEConv(hidden_channels, out_channels)
        self.dropout = dropout

    def forward(self, x, edge_index):
        x = self.conv1(x, edge_index)
        x = F.relu(x)
        x = F.dropout(x, p=self.dropout, training=self.training)
        x = self.conv2(x, edge_index)
        return x

# ================================
# Load Model / Scaler / RAG
# ================================
@st.cache_resource
def load_model(platform, model_choice, in_dim=11):
    model_map = {"GraphSAGE": "graphsage", "GCN": "gcn", "GAT": "gat"}
    model_type = model_map.get(model_choice, "graphsage")
    model_path = os.path.join(MODELS_DIR, f"{platform.lower()}_{model_type}.pt")

    if not os.path.exists(model_path):
        st.error(f"⚠ Model not found: {model_path}")
        return None

    if model_choice == "GraphSAGE":
        model = GraphSAGENet(in_dim)
    elif model_choice == "GCN":
        from torch_geometric.nn import GCNConv
        class GCNNet(torch.nn.Module):
            def __init__(self, in_channels, hidden_channels=64, out_channels=2, dropout=0.5):
                super().__init__()
                self.conv1 = GCNConv(in_channels, hidden_channels)
                self.conv2 = GCNConv(hidden_channels, out_channels)
                self.dropout = dropout
            def forward(self, x, edge_index):
                x = self.conv1(x, edge_index)
                x = F.relu(x)
                x = F.dropout(x, p=self.dropout, training=self.training)
                x = self.conv2(x, edge_index)
                return x
        model = GCNNet(in_dim)
    else:
        from torch_geometric.nn import GATConv
        class GATNet(torch.nn.Module):
            def __init__(self, in_channels, hidden_channels=32, out_channels=2, heads=2, dropout=0.5):
                super().__init__()
                self.conv1 = GATConv(in_channels, hidden_channels, heads=heads)
                self.conv2 = GATConv(hidden_channels * heads, out_channels, heads=1)
                self.dropout = dropout
            def forward(self, x, edge_index):
                x = self.conv1(x, edge_index)
                x = F.elu(x)
                x = F.dropout(x, p=self.dropout, training=self.training)
                x = self.conv2(x, edge_index)
                return x
        model = GATNet(in_dim)

    model.load_state_dict(torch.load(model_path, map_location="cpu"), strict=False)
    model.eval()
    return model

@st.cache_resource
def load_scaler(platform):
    scaler_path = os.path.join(MODELS_DIR, f"scaler_{platform.lower()}.pkl")
    if not os.path.exists(scaler_path):
        st.warning(f"⚠ No scaler found for {platform}. Using unscaled inputs.")
        return None
    with open(scaler_path, "rb") as f:
        return pickle.load(f)

@st.cache_resource
def load_rag():
    import faiss
    index = faiss.read_index(os.path.join(RAG_INDEX_DIR, "kb_index.faiss"))
    emb = np.load(os.path.join(RAG_INDEX_DIR, "kb_emb.npy"))
    meta = pickle.load(open(os.path.join(RAG_INDEX_DIR, "kb_meta.pkl"), "rb"))
    return index, emb, meta

rag_index, rag_emb, rag_meta = load_rag()
from sentence_transformers import SentenceTransformer
import torch

try:
    embedder = SentenceTransformer("all-MiniLM-L6-v2", device="cpu")
except NotImplementedError as e:
    if "meta tensor" in str(e):
        # fallback
        embedder = SentenceTransformer("all-MiniLM-L6-v2")
        embedder.to("cpu")
    else:
        raise



def retrieve_from_index(query, index, meta, embedder, top_k=5):
    q_emb = embedder.encode([query], convert_to_numpy=True, normalize_embeddings=True)
    D, I = index.search(q_emb, top_k)
    results = [meta[i] for i in I[0]]
    return results

# ================================
# Sidebar Configuration
# ================================
st.sidebar.title("⚙️ Configuration")
platform = st.sidebar.selectbox("Select Platform", ["Instagram", "Facebook"])
model_choice = st.sidebar.selectbox("🧩 Choose GNN Model", ["GraphSAGE", "GCN", "GAT"], index=0)
input_mode = st.sidebar.radio("Input Mode", ["Manual Input", "Upload CSV"])
llm_model = st.sidebar.selectbox("🧠 Choose LLM", ["distilgpt2", "gpt2", "microsoft/phi-2"])
threshold_enabled = st.sidebar.checkbox("Enable Confidence Threshold", value=True)
threshold_value = st.sidebar.slider("Threshold (for Fake detection)", 0.0, 1.0, 0.6, 0.05)


# ================================
# Tabs for Navigation
# ================================
tabs = st.tabs(["🏠 Overview", "🔍 Prediction", "🧠 Explanations", "ℹ️ About"])

# --------------------------------
# 🏠 OVERVIEW (Enhanced UI)
# --------------------------------
with tabs[0]:
    st.markdown("<h1>🔎 Fake Account Detection Dashboard</h1>", unsafe_allow_html=True)
    st.markdown("""
    <p style='font-size:18px;'>
    Welcome to the <b>Fake Account Detection System</b> — an AI-powered platform that uses <b>Graph Neural Networks</b> (GNNs) and <b>Language Models</b> 
    to identify fake or bot-managed social media accounts on <b>Instagram</b> and <b>Facebook</b>.
    </p>

    <h3>🌐 Features</h3>
    <ul style='font-size:17px;'>
        <li>🧩 <b>GraphSAGE, GCN, and GAT</b> models for deep relational learning</li>
        <li>🔍 <b>FAISS-based RAG retrieval</b> to find similar account patterns</li>
        <li>🧠 <b>Local LLM explanations</b> for human-understandable insights</li>
        <li>⚙️ Interactive and real-time classification via Streamlit</li>
    </ul>

    <h3>🚀 How It Works</h3>
    <ol style='font-size:17px;'>
        <li>Provide account data manually or upload a CSV.</li>
        <li>Select a Graph Neural Network model to analyze relationships.</li>
        <li>AI predicts whether an account is <b>Real</b> or <b>Fake</b>.</li>
        <li>View AI-generated explanations and similar case references.</li>
    </ol>

    <h3>📊 Why It Matters</h3>
    <p style='font-size:17px;'>Fake profiles can spread misinformation, manipulate trends, and harm online communities. 
    This tool brings transparency and explainability to social media AI analysis, helping both researchers and users detect 
    fraudulent activities effectively.</p>

    <hr>
    <center>
    <p style='font-size:16px; color:#aaa;'>🧠 Powered by Graph Learning • 🔍 Enhanced with RAG • 💬 Explained by LLMs</p>
    </center>
    """, unsafe_allow_html=True)




# Prediction Tab
with tabs[1]:
    st.header("🔍 Prediction Panel")
    sample = None

    if input_mode == "Manual Input":
        st.subheader(f"📥 Manual Input for {platform}")

        if platform == "Instagram":
            # ✅ 11 features
            followers = st.slider("Followers", 0, 10000, 200)
            following = st.slider("Following", 0, 10000, 100)
            posts = st.slider("Posts Shared", 0, 500, 20)
            mutual = st.slider("Mutual Friends", 0, 500, 5)
            has_pic = st.checkbox("Profile Picture", True)
            has_link = st.checkbox("External Link", False)
            has_threads = st.checkbox("Threads Enabled", False)
            ff_ratio = (followers + 1) / (following + 1)
            posts_per_follower = (posts + 1) / (followers + 1)
            sample = pd.DataFrame([{
                "Followers": followers,
                "Following": following,
                "Posts": posts,
                "Mutual Friends": mutual,
                "Following/Followers": following/(followers+1),
                "Posts/Followers": posts/(followers+1),
                "has_profile_pic": int(has_pic),
                "has_external_link": int(has_link),
                "has_threads": int(has_threads),
                "ff_ratio": ff_ratio,
                "posts_per_follower": posts_per_follower
            }])
        else:
            # ✅ Facebook → 9 features
            friends = st.slider("Friends", 0, 5000, 250)
            following = st.slider("Following", 0, 5000, 200)
            community = st.slider("Communities", 0, 100, 10)
            age = st.slider("Account Age (days)", 0, 5000, 1000)
            posts = st.slider("Posts Shared", 0, 1000, 50)
            urls = st.slider("URLs Shared", 0, 100, 3)
            media = st.slider("Photos/Videos Shared", 0, 1000, 30)
            avg_comments = st.slider("Avg comments/post", 0.0, 100.0, 2.0)
            avg_likes = st.slider("Avg likes/post", 0.0, 1000.0, 10.0)
            sample = pd.DataFrame([{
                "friends": friends,
                "following": following,
                "community": community,
                "age": age,
                "posts": posts,
                "urls": urls,
                "media": media,
                "avg_comments": avg_comments,
                "avg_likes": avg_likes
            }])

    else:
        uploaded_file = st.file_uploader("📂 Upload CSV file", type="csv")
        if uploaded_file is not None:
            sample = pd.read_csv(uploaded_file)
            st.dataframe(sample.head())

    if st.button("🚀 Predict Fake or Real"):
        if sample is not None:
            in_dim = sample.shape[1]
            st.write(f"🧮 Input feature count for {platform}: {in_dim}")
            model = load_model(platform, model_choice, in_dim)
            scaler = load_scaler(platform)
            if model is None:
                st.error(f"⚠ No trained model found for {platform}.")
            else:
                X_scaled = scaler.transform(sample.values) if scaler else sample.values
                X = torch.tensor(X_scaled, dtype=torch.float)
                edge_index = torch.tensor([list(range(len(sample))), list(range(len(sample)))], dtype=torch.long)
                with torch.no_grad():
                    logits = model(X, edge_index)
                    probs = F.softmax(logits, dim=1).numpy()

                for i, p in enumerate(probs):
                    conf = np.max(p)
                    pred_index = np.argmax(p)

                    # ✅ Facebook label inversion fix
                    if threshold_enabled and conf < threshold_value:
                        label = "Uncertain"
                    else:
                        if platform == "Facebook":
                            label = "Fake" if pred_index == 0 else "Real"
                        else:
                            label = "Fake" if pred_index == 1 else "Real"

                    emoji = "🟢" if label == "Real" else ("🔴" if label == "Fake" else "🟡")
                    st.markdown(f"## {emoji} Row {i+1}: {label} ({conf*100:.2f}%)")

                    st.session_state["sample"] = sample
                    st.session_state["platform"] = platform
                    st.session_state["result"] = label
                st.success(f"✅ Prediction complete using **{model_choice}** model!")

# ==============================================
# 🧠 EXPLANATION TAB (RAG + Feature-Based LLM)
# ==============================================
with tabs[2]:
    st.header("🧠 Explanation (RAG + AI Reasoning)")
    col1, col2 = st.columns(2)

    sample = st.session_state.get("sample")
    platform = st.session_state.get("platform")

    if sample is None:
        st.warning("⚠️ Please make a prediction first.")
    else:
        for i in range(len(sample)):
            query = ", ".join([f"{c}={v}" for c, v in sample.iloc[i].items()])

            # 🔹 Retrieve similar cases using RAG
            related_cases = retrieve_from_index(query, rag_index, rag_meta, embedder, top_k=5)

            # ===========================
            # 🔹 Left Column — RAG Results
            # ===========================
            with col1:
                st.subheader(f"🔍 RAG Retrieved Cases — Row {i+1}")
                if related_cases:
                    for case in related_cases:
                        st.info(
                            f"**{case.get('platform', 'Unknown').capitalize()} | {case.get('label', 'Unknown')}**\n\n"
                            f"{case.get('doc', '')}"
                        )
                else:
                    st.warning("⚠️ No similar cases found in the knowledge base.")

            # ===========================
            # 🔹 Right Column — Feature-Based Reasoning
            # ===========================
            with col2:
                st.subheader(f"💬 Feature-Based AI Reasoning — Row {i+1}")

                # Get model's actual prediction from session
                result_label = st.session_state.get("result", "Unknown")

                # Generate reasoning based on prediction
                from llm_utils import generate_reasoning
                reasoning_text = generate_reasoning(query, prediction=result_label)

                # Display reasoning neatly
                st.markdown(reasoning_text, unsafe_allow_html=True)
                st.markdown("<hr style='border:1px solid #444; margin:10px 0;'>", unsafe_allow_html=True)


            
# --------------------------------
# ℹ️ ABOUT (Enhanced UI)
# --------------------------------
with tabs[3]:
    st.markdown("<h1>ℹ️ About This Project</h1>", unsafe_allow_html=True)
    st.markdown("""
    <h3>👨‍💻 Developer</h3>
    <p><b>GROUP 10</b><br>B.Tech in Artificial Intelligence & Data Science<br>
    Vishwakarma Institute of Technology, Pune</p>

    <h3>🧩 Project Overview</h3>
    <p>
    The Fake Account Detector is designed to recognize patterns in user behavior and social connections using 
    advanced <b>Graph Neural Network architectures</b>. Each prediction is accompanied by <b>AI reasoning</b> 
    and <b>retrieved knowledge</b> to make the system interpretable.
    </p>

    <h3>⚙️ Technology Stack</h3>
    <ul style='font-size:17px;'>
        <li>🧠 <b>AI Models:</b> GraphSAGE, GCN, GAT</li>
        <li>🧩 <b>Explainability:</b> FAISS (RAG) + Local LLM reasoning</li>
        <li>💻 <b>Frontend:</b> Streamlit</li>
        <li>🔬 <b>Backend:</b> PyTorch & Torch Geometric</li>
    </ul>

    <h3>🌍 Applications</h3>
    <ul style='font-size:17px;'>
        <li>Detecting fake or spam accounts across social networks</li>
        <li>Monitoring automated behavior and suspicious engagement</li>
        <li>Supporting academic and cybersecurity research</li>
    </ul>

    <hr>
    <center>
    <p style='font-size:15px; color:#aaa;'>Made with ❤️ by GROUP 10 | © 2025 Fake Account Detector</p>
    </center>
    """, unsafe_allow_html=True)
