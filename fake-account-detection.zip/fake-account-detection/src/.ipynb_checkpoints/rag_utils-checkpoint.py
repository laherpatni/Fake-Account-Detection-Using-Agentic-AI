# ==============================================
# src/rag_utils.py — FAISS RAG Helper (Final Stable Version)
# ==============================================

import os
import numpy as np
import faiss
import pickle
import copy
from sentence_transformers import SentenceTransformer

# ==============================================
# 🔹 Build FAISS Index (only if you re-create it)
# ==============================================
def build_faiss_index(docs, meta, index_path="rag_index/kb_index.faiss"):
    """
    Build a FAISS index from text documents and metadata.
    """
    os.makedirs(os.path.dirname(index_path), exist_ok=True)

    model = SentenceTransformer("all-MiniLM-L6-v2")
    embeddings = model.encode(docs, show_progress_bar=True, convert_to_numpy=True, normalize_embeddings=True)

    dim = embeddings.shape[1]
    index = faiss.IndexFlatIP(dim)
    index.add(embeddings)

    np.save(index_path.replace(".faiss", "_emb.npy"), embeddings)
    with open(index_path.replace(".faiss", "_meta.pkl"), "wb") as f:
        pickle.dump(meta, f)
    faiss.write_index(index, index_path)

    print(f"✅ FAISS index built successfully and saved to {index_path}")
    print(f"📊 Total documents indexed: {len(docs)}")


# ==============================================
# 🔹 Load FAISS Index with Safe Label Checking
# ==============================================
def load_faiss_index(index_dir="rag_index"):
    """
    Load a FAISS index and ensure labels are consistent:
      - Instagram: 0 = Real, 1 = Fake
      - Facebook: 0 = Real, 1 = Fake
    If inverted labels are detected, they are auto-corrected.
    """
    index_path = os.path.join(index_dir, "kb_index.faiss")
    emb_path = os.path.join(index_dir, "kb_emb.npy")
    meta_path = os.path.join(index_dir, "kb_meta.pkl")

    if not all(os.path.exists(p) for p in [index_path, emb_path, meta_path]):
        raise FileNotFoundError("❌ Missing FAISS files (index, embeddings, or metadata).")

    index = faiss.read_index(index_path)
    embeddings = np.load(emb_path)
    with open(meta_path, "rb") as f:
        meta = pickle.load(f)

    corrected_meta = []
    for m in meta:
        m_copy = copy.deepcopy(m)
        platform = m_copy.get("platform", "").lower()
        label = str(m_copy.get("label", "")).strip()

        # --- Safety: normalize numeric or string labels ---
        if label in ["0", 0]:
            m_copy["label"] = "Real"
        elif label in ["1", 1]:
            m_copy["label"] = "Fake"

        # --- Consistency check ---
        if "instagram" in platform:
            # Heuristic correction if it's clearly reversed
            if "followers" in m_copy.get("doc", "").lower():
                if "few followers" in m_copy["doc"].lower() and m_copy["label"] == "Real":
                    m_copy["label"] = "Fake"
                elif "many followers" in m_copy["doc"].lower() and m_copy["label"] == "Fake":
                    m_copy["label"] = "Real"

        elif "facebook" in platform:
            # Facebook fake detection often relates to low friends + high posts
            if "friends" in m_copy.get("doc", "").lower():
                if "few friends" in m_copy["doc"].lower() and m_copy["label"] == "Real":
                    m_copy["label"] = "Fake"
                elif "many friends" in m_copy["doc"].lower() and m_copy["label"] == "Fake":
                    m_copy["label"] = "Real"

        corrected_meta.append(m_copy)

    print(f"✅ FAISS index loaded: {len(corrected_meta)} records, dim={embeddings.shape[1]}")
    return index, embeddings, corrected_meta


# ==============================================
# 🔹 Retrieve Top-k Relevant Examples
# ==============================================
def retrieve_from_index(query, index, meta, embedder=None, top_k=5):
    """
    Retrieve top-k most similar cases from the FAISS index.
    Returns a list of dicts: [{'platform': ..., 'label': ..., 'doc': ...}, ...]
    """
    if embedder is None:
        embedder = SentenceTransformer("all-MiniLM-L6-v2")

    q_emb = embedder.encode([query], convert_to_numpy=True, normalize_embeddings=True)
    D, I = index.search(q_emb, top_k)

    results = []
    for idx in I[0]:
        case = meta[idx]
        if isinstance(case, dict):
            results.append(case)
        else:
            results.append({"label": "Unknown", "doc": str(case)})
    return results


# ==============================================
# 🔹 Debug Utility (Optional)
# ==============================================
def preview_meta_summary(meta, n=10):
    """
    Print a quick sample of metadata labels and platforms for debugging.
    """
    print("📋 Sample Metadata Records:")
    for m in meta[:n]:
        print(f"- {m.get('platform', '?').title():10} | Label: {m.get('label', '?'):5} | Doc: {m.get('doc', '')[:80]}...")
