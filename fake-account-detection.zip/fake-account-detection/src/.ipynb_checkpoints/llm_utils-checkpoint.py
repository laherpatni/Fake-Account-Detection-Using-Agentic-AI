"""
llm_utils.py — Final Compatible Version
---------------------------------------
Works perfectly with:
reasoning_text = generate_reasoning(query, prediction=result_label)
"""

from typing import Optional

def generate_reasoning(query: str, prediction: Optional[str] = None, model_name: Optional[str] = None) -> str:
    """
    Generate reasoning explanation based on the model's prediction.
    Compatible with app.py — accepts (query, prediction=...).

    Args:
        query (str): Account feature string.
        prediction (str): Model prediction ("Real", "Fake", or "Uncertain").
        model_name (str): Optional; for compatibility only.

    Returns:
        str: Human-readable reasoning text.
    """

    q = query.lower()

    # Detect platform
    if "followers" in q or "threads" in q:
        platform = "Instagram"
    elif "friends" in q or "avg_likes" in q:
        platform = "Facebook"
    else:
        platform = "Unknown"

    # Default if no prediction
    if not prediction:
        prediction = "Uncertain"

    # ================================
    # Fake Account Reasoning
    # ================================
    if prediction.lower() == "fake":
        reasoning = (
            f"🔴 **Conclusion: Fake**\n\n"
            f"• This {platform} account exhibits unusual activity patterns and engagement behavior.\n"
            "• The ratio of followers/friends to activity appears inconsistent or automated.\n"
            "• The presence of excessive external links, promotional content, or sudden follower changes suggests non-genuine behavior.\n"
            "• The interaction rate seems low compared to the account size, indicating potential bot-driven activity.\n"
            "• Overall, this profile is likely **fake or spam-related**.\n\n"
            f"📱 **Platform analyzed:** {platform}"
        )

    # ================================
    # Real Account Reasoning
    # ================================
    elif prediction.lower() == "real":
        reasoning = (
            f"🟢 **Conclusion: Real**\n\n"
            f"• This {platform} account shows consistent human-like engagement and organic growth.\n"
            "• Followers, activity rate, and content style appear balanced and authentic.\n"
            "• Regular interactions, mutual connections, and natural posting frequency support genuine behavior.\n"
            "• No signs of automation, spam, or artificial engagement are observed.\n"
            f"📱 **Platform analyzed:** {platform}"
        )

    # ================================
    # Uncertain / Fallback
    # ================================
    elif prediction.lower() == "uncertain":
        reasoning = (
            f"🟡 **Conclusion: Uncertain**\n\n"
            f"• The signals for this {platform} account are ambiguous or borderline.\n"
            "• Engagement and connection metrics do not strongly indicate either real or fake behavior.\n"
            "• Additional verification or manual review may be required to reach a confident decision."
        )

    else:
        reasoning = (
            f"⚪ **Conclusion: Unknown**\n\n"
            f"Prediction type not recognized for this {platform} account."
        )

    return reasoning
