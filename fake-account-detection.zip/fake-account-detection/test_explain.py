from src.rag_utils import explain_prediction

# Example account features
features = {
    "followers": 12,
    "following": 500,
    "profile_pic": False,
    "bio": "Check my website",
    "external_link": True
}

label = "fake"

# Run explanation
print(explain_prediction(features, label))
