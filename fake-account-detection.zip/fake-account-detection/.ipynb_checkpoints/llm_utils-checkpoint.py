"""
llm_utils.py — AI Reasoning Module for Fake Account Detection
-------------------------------------------------------------
✅ Clean, short reasoning for Instagram & Facebook
✅ No repeated lines ("State final conclusion...")
✅ Offline-friendly (heuristic based)
✅ Color-coded output for Streamlit
"""

import re
import numpy as np
from typing import Optional, List

# Optional LLM import (not required)
try:
    from transformers import pipeline, AutoTokenizer, AutoModelForCausalLM
    _transformers_available = True
except ImportError:
    _transformers_available = False


# ================================================================
# 🧠 Helper: Local LLM Text Generation (optional)
# ================================================================
def _use_local_model(prompt: str, model_name: str = "distilgpt2", max_length: int = 200) -> Optional[str]:
    """Generate a single-line reasoning using a small local Hugging Face model."""
    if not _transformers_available:
        return None

    try:
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForCausalLM.from_pretrained(model_name)
        gen = pipeline("text-generation", model=model, tokenizer=tokenizer)

        out = gen(
            prompt,
            max_length=max_length,
            do_sample=True,
            temperature=0.2,
            top_p=0.9,
            num_return_sequences=1,
            no_repeat_ngram_size=4,
        )

        text = out[0]["generated_text"].replace(prompt, "").strip()
        text = re.sub(r"(state final conclusion.*)+", "", text, flags=re.I).strip()

        # Reject repeated garbage or empty outputs
        if not text or text.lower().count("fake or real") > 1:
            return None
        return text

    except Exception:
        return None


# ================================================================
# 🧩 Heuristic Fallback Logic (Clean & Fast)
# ================================================================
def _heuristic_reasoning(query: str) -> str:
    """
    Generates reasoning based on simple rule-based logic.
    Works offline and ensures concise readable output.
    """
    q = query.lower()
    numbers = [float(s) for s in re.findall(r"[-+]?\d*\.\d+|\d+", q)]
    avg_value = np.mean(numbers) if numbers else 0

    # Detect platform
    if "followers" in q or "threads" in q:
        platform = "Instagram"
    elif "friends" in q or "avg_likes" in q:
        platform = "Facebook"
    else:
        platform = "Unknown"

    # Decision rules
    if "external_link" in q or "url" in q:
        conclusion = "Fake"
        reason = "Frequent external links or URLs suggest spam or automation."
    elif avg_value < 50:
        conclusion = "Fake"
        reason = "Very low engagement or network size — likely a bot or inactive account."
    elif avg_value > 300 and "mutual" in q:
        conclusion = "Real"
        reason = "High mutual connections and engagement — genuine social behavior."
    elif avg_value > 300:
        conclusion = "Real"
        reason = "Balanced activity and interaction metrics — looks authentic."
    else:
        conclusion = "Real"
        reason = "Moderate activity with natural interaction patterns."

    color = "🟢" if conclusion == "Real" else "🔴"

    return f"{color} **Conclusion:** {conclusion}\n\n• {reason}\n• Platform analyzed: {platform}"


# ================================================================
# 🧠 Main Public Function — generate_reasoning()
# ================================================================
def generate_reasoning(
    query: str,
    related_cases: Optional[List[dict]] = None,
    model_name: str = "gpt2",
    max_length: int = 200
) -> str:
    """
    Main reasoning function used by app.py.
    Generates a short explanation for why the account is Real or Fake.
    """
    # Simple, single-line LLM prompt (optional use)
    prompt = (
        f"Given the following account metrics, output ONE short line like:\n"
        f"Example: 'Conclusion: Fake — low engagement and many URLs shared.'\n\n"
        f"Account Info: {query}\n\n"
        f"Now give only one line conclusion:"
    )

    # Try to use LLM if available and stable
    text = _use_local_model(prompt, model_name, max_length)
    if text:
        # Clean up unnecessary repetition or artifacts
        text = re.sub(r"(\bconclusion\b.*\bconclusion\b.*)+", "", text, flags=re.I)
        text = text.strip()
        if not text.lower().startswith("conclusion"):
            text = "Conclusion: " + text
        return f"🧠 **LLM Insight:** {text}"

    # Fallback to deterministic reasoning
    return _heuristic_reasoning(query)


def generate_reasoning(
    query: str,
    related_cases: Optional[List[dict]] = None,
    model_name: str = "distilgpt2",
    max_length: int = 200
) -> str:
    """
    Main reasoning function used by app.py.
    Generates a short explanation for why the account is Real or Fake.
    """
    # Simple, single-line LLM prompt (optional use)
    prompt = (
        f"Given the following account metrics, output ONE short line like:\n"
        f"Example: 'Conclusion: Fake — low engagement and many URLs shared.'\n\n"
        f"Account Info: {query}\n\n"
        f"Now give only one line conclusion:"
    )

    # Try to use LLM if available and stable
    text = _use_local_model(prompt, model_name, max_length)
    if text:
        # Clean up unnecessary repetition or artifacts
        text = re.sub(r"(\bconclusion\b.*\bconclusion\b.*)+", "", text, flags=re.I)
        text = text.strip()
        if not text.lower().startswith("conclusion"):
            text = "Conclusion: " + text
        return f"🧠 **LLM Insight:** {text}"

    # Fallback to deterministic reasoning
    return _heuristic_reasoning(query)


def generate_reasoning(
    query: str,
    related_cases: Optional[List[dict]] = None,
    model_name: str = "phi2",
    max_length: int = 200
) -> str:
    """
    Main reasoning function used by app.py.
    Generates a short explanation for why the account is Real or Fake.
    """
    # Simple, single-line LLM prompt (optional use)
    prompt = (
        f"Given the following account metrics, output ONE short line like:\n"
        f"Example: 'Conclusion: Fake — low engagement and many URLs shared.'\n\n"
        f"Account Info: {query}\n\n"
        f"Now give only one line conclusion:"
    )

    # Try to use LLM if available and stable
    text = _use_local_model(prompt, model_name, max_length)
    if text:
        # Clean up unnecessary repetition or artifacts
        text = re.sub(r"(\bconclusion\b.*\bconclusion\b.*)+", "", text, flags=re.I)
        text = text.strip()
        if not text.lower().startswith("conclusion"):
            text = "Conclusion: " + text
        return f"🧠 **LLM Insight:** {text}"

    # Fallback to deterministic reasoning
    return _heuristic_reasoning(query)